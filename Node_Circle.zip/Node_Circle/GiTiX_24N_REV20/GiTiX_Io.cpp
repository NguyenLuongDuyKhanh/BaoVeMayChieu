#include "GiTiX_Io.h"

static const GiTiX_IO_t GiTiX_IO = {
    __Io_init,
    __Io_ledSet,
    __Io_virabationSet,
    __Io_buzzerSet,
    __Io_getButton,
    __Io_getBattery};

static IO_State_t ledD1State, ledD2State, ledD3State, vibratorState, buzzerState;

void __Io_init(void)
{
    // Button
    pinMode(USER_BTN0, INPUT);
    digitalWrite(USER_BTN0, HIGH);

    pinMode(USER_BTN1, INPUT);
    digitalWrite(USER_BTN1, HIGH);

    // Led
    pinMode(LED_D1, OUTPUT);
    digitalWrite(LED_D1, LOW);
    ledD1State = OFF;

    pinMode(LED_D2, OUTPUT);
    digitalWrite(LED_D2, LOW);
    ledD2State = OFF;

    pinMode(LED_D3, OUTPUT);
    digitalWrite(LED_D3, LOW);
    ledD3State = OFF;

    // Vibrator
    pinMode(VIBRATOR, OUTPUT);
    digitalWrite(VIBRATOR, LOW);
    vibratorState = OFF;

    // Buzzer
    pinMode(BUZZER, OUTPUT);
    analogWrite(BUZZER, 0);
    buzzerState = OFF;
}

void __Io_ledSet(IO_Led_t led, IO_State_t value)
{
    switch (led)
    {
    case LED1:
        ledD1State = value;
        digitalWrite(LED_D1, (ledD1State == ON ? HIGH : LOW));
        break;
    case LED2:
        ledD2State = value;
        digitalWrite(LED_D2, (ledD2State == ON ? HIGH : LOW));
        break;
    case LED3:
        ledD3State = value;
        digitalWrite(LED_D3, (ledD3State == ON ? HIGH : LOW));
        break;
    default:
        break;
    }
}

void __Io_virabationSet(IO_State_t value)
{
    vibratorState = value;
    digitalWrite(VIBRATOR, (vibratorState == ON ? HIGH : LOW));
}

void __Io_buzzerSet(IO_State_t value)
{
    buzzerState = value;
    digitalWrite(VIBRATOR, (buzzerState == ON ? 100 : 0));
}

IO_Button_t __Io_getButton(void)
{
    if (digitalRead(USER_BTN0))
    {
        return BUTTON_0;
    }
    else if (digitalRead(USER_BTN1))
    {
        return BUTTON_1;
    }
    else
    {
        return NONE;
    }
}

uint16_t __Io_getBattery(void)
{
    return (uint16_t) analogRead(BATTERY_ADC_PIN);
}
