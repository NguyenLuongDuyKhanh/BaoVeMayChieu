#ifndef __GiTiX_24N_REV20_H__
#define __GiTiX_24N_REV20_H__

/*********** LIBRARY ***********/
#include "Radio.h"
#include "GiTiX_Io.h"
#include <avr/wdt.h>

/*********** DEFINE ***********/
#define RF_FREQUENCY 2400000000 // Hz
#define TX_OUTPUT_POWER 13      // dBm
#define RX_TIMEOUT_TICK_SIZE RADIO_TICK_SIZE_1000_US
#define RX_TIMEOUT_VALUE 1000 // ms
#define TX_TIMEOUT_VALUE 1000 // ms
#define BUFFER_SIZE 15

/*********** MACRO ***********/
#define isSetBit(reg, mask) (reg & mask)

/*********** METHOD ***********/
void txDoneIRQ(void);
void rxDoneIRQ(void);
void txTimeoutIRQ(void);
void rxTimeoutIRQ(void);

void loraInit(void);
void setListen(void);
void setTransmit(uint8_t *payload, uint8_t size);

void wdtInit(void);
void wdtClear(void);

/*********** TYPEDEF ***********/
typedef enum
{
    IDLE = 0,
    TX_DONE,
    RX_DONE,
    TX_TIMEOUT,
    RX_TIMEOUT
} AppState_t;

/*********** VARIABLE ***********/
const uint16_t rxIrqMask = IRQ_RX_DONE | IRQ_RX_TX_TIMEOUT;
const uint16_t txIrqMask = IRQ_TX_DONE | IRQ_RX_TX_TIMEOUT;

volatile AppState_t appState = IDLE;

const RadioCallbacks_t callbacks = {
    txDoneIRQ,
    rxDoneIRQ,
    NULL,
    NULL,
    txTimeoutIRQ,
    rxTimeoutIRQ,
    NULL,
    NULL,
    NULL};

#endif /* __GiTiX_24N_REV20_H__ */
