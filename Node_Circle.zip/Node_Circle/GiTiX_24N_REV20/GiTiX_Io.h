#ifndef __GITIX_IO_H__
#define __GITIX_IO_H__

/*********** LIBRARY ***********/
#include <Arduino.h>
#include "Config.h"

/*********** DEFINE ***********/

/*********** DATA TYPE ***********/
typedef enum
{
    LED1 = 0,
    LED2,
    LED3
} IO_Led_t;

typedef enum
{
    OFF = 0,
    ON
} IO_State_t;

typedef enum
{
    NONE = 0,
    BUTTON_0,
    BUTTON_1
} IO_Button_t;

/*********** METHOD ***********/
void __Io_init(void);
void __Io_ledSet(IO_Led_t led, IO_State_t value);
void __Io_virabationSet(IO_State_t value);
void __Io_buzzerSet(IO_State_t value);
IO_Button_t __Io_getButton(void);
uint16_t __Io_getBattery(void);

typedef struct
{
    void (*init)(void);
    void (*ledSet)(IO_Led_t led, IO_State_t value);
    void (*virabationSet)(IO_State_t value);
    void (*buzzerSet)(IO_State_t value);
    IO_Button_t (*getButton)(void);
    uint16_t (*getBattery)(void);
} GiTiX_IO_t;

/*********** VARIABLE ***********/
extern const GiTiX_IO_t GiTiX_IO;

#endif /* __GITIX_IO_H__ */
