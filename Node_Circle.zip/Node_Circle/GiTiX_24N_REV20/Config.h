#ifndef __CONFIG_H__
#define __CONFIG_H__

//#define NSS 10
//#define NRESET 6
//#define BUSY 5
//#define DIO1 2
//#define DIO2 3
//#define DIO3 4

#define NSS A0
#define NRESET A1
#define BUSY A2
#define DIO1 2
#define DIO2 3
#define DIO3 -1
#define BATTERY_ADC_PIN -1

#define USER_BTN0 9
#define USER_BTN1 -1

#define VIBRATOR A5
#define BUZZER -1

#define LED_D1 10
#define LED_D2 8
#define LED_D3 7

#define LED_D5 4
#define LED_D6 A4
#define LED_D7 A3
#endif /* CONFIG_H__ */
